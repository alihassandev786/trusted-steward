import 'package:flutter/material.dart';

class GivingEntry {
  const GivingEntry({
    required this.title,
    required this.intent,
    required this.recipient,
    required this.amount,
    required this.date,
    this.notes = '',
    this.recurring = false,
    this.icon = Icons.volunteer_activism,
  });

  final String title;
  final String intent;
  final String recipient;
  final double amount;
  final DateTime date;
  final String notes;
  final bool recurring;
  final IconData icon;

  static GivingEntry demo() {
    return GivingEntry(
      title: 'Church Giving',
      intent: 'Fruits',
      recipient: 'Community Church',
      amount: 100,
      date: DateTime(2026, 9, 10),
      recurring: true,
      icon: Icons.church,
      notes:
      'Monthly pledge for local community outreach and youth missions. '
          'Dedicated during the Sunday gathering offering.',
    );
  }
}

class SavingsGoal {
  const SavingsGoal({
    required this.title,
    required this.targetAmount,
    required this.currentAmount,
    required this.targetDate,
  });

  final String title;
  final double targetAmount;
  final double currentAmount;
  final DateTime targetDate;
}

typedef GivingSaver = Future<void> Function(GivingEntry entry);
typedef SavingsGoalSaver = Future<void> Function(SavingsGoal goal);